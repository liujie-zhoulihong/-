from PIL import  Image
from django.shortcuts import render
from django.http import HttpResponse
from common.models import Goods,Types
from datetime import  datetime
import time,os
from django.db.models import Q
from django.core.paginator import Paginator


# Create your views here.

def index(request,pIndex):
    #商品类别信息
    tlist=Types.objects.extra(select={'_has':'concat(path,id)'}).order_by('_has')
    for ob in tlist:
        ob.pname = '----'* (ob.path.count(',')-1)
    #添加搜索栏
    #获取商品信息查询对象，定义一个空列表接受关键词
    mod=Goods.objects
    mywhere=[]

    #获取并判断封装关键词keyword
    kw = request.GET.get('keyword',None)
    if kw:
        list=mod.filter(goods__contains=kw)
        mywhere.append('keyword='+kw)
    else:
        list=mod.filter()
    #获取、判断并封装typeid搜索条件
    typeid = request.GET.get('typeid','0')
    if typeid != '0':
        #Q多条件语句查询，返回id列表值，flat=True只返回值组成的列表
        tids=Types.objects.filter(Q(id=typeid) | Q(pid=typeid)).values_list('id',flat=True)
        # typeid_in=tids,在这个tids里表中的typeid
        list=list.filter(typeid__in=tids)
        mywhere.append('typeid='+list)
    #获取并封装商品状态state搜索条件
    state=request.GET.get('state','')
    if state != '':
        list=list.filter(state=state)
        mywhere.append('state=' + state)

    #执行分页操作
    pIndex=int(pIndex)
    page=Paginator(list,5)#添加分页数据，以每页5条数据展示
    maxpages=page.num_pages#数据的总数
    if pIndex > maxpages:
        pIndex=maxpages
    if pIndex<1:
        pIndex=1
    list2=page.page(pIndex)#获取当前页面的数据
    plist=page.page_range#页码数列表
    #遍历商品信息列表，并获得对应的商品类别信息
    for vo in list2:
        ty = Types.objects.get(id=vo.typeid)
        vo.typename = ty.name
    context = {'typelist':tlist,"goodslist":list2,'plist':plist,'pIndex':pIndex,'maxpages':maxpages,'mywhere':mywhere,'typeid':int(typeid)}
    return  render(request,'myadmin/goods/index.html',context)

def save_img(img):
    # 获取图片格式
    filename = img.name.split('.').pop()
    #源文件名
    myfilename = str(time.time())+ '.'+ filename
    #打开要存储图片的路径，并以流传输的方式把上传的图片保存进去
    desc = open(os.path.join('./static/goods/',myfilename),'wb+')
    for chunk in img.chunks():
        desc.write(chunk)
    desc.close()
    #执行缩放操作
    im=Image.open('./static/goods/'+myfilename)
    #缩放到220*220
    im.thumbnail((220,220))
    im.save('./static/goods/m_'+myfilename,None)
    # 缩放到375*375
    im.thumbnail((375, 375))
    im.save('./static/goods/'+myfilename, None)
    # 缩放到20*20
    im.thumbnail((20,20))
    im.save('./static/goods/s_'+myfilename, None)
    return myfilename
def add(request):
    #加载添加页面并判断request.method是哪一个参数
   if request.method == 'GET':
        list=Types.objects.extra(select={'_has':'concat(path,id)'}).order_by('_has')
        for ob in list:
            ob.pname = "&nbsp"* (ob.path.count(',')-1)
        context={'goodlist':list}
        return render(request,'myadmin/goods/add.html',context)
   else:
       context={}
       try:
           #获取图片名字
           myfile=request.FILES.get('pic',None)
           if not myfile:
               return  HttpResponse('没有上传图片')
           filename=save_img(myfile)

           ob=Goods()
           ob.typeid=request.POST['typeid']
           ob.goods = request.POST['goods']
           ob.company = request.POST['company']
           ob.content = request.POST['content']
           ob.price = request.POST['price']
           ob.picname = filename
           ob.store = request.POST['store']
           ob.state = 1
           ob.addtime=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
           ob.save()
           context['info']='添加成功'
       except Exception as a:
            print(a)
            context['info']='添加失败'
       return render(request,'myadmin/info.html',context)

def del_oldfile(filename):
    os.remove('./static/goods/' + filename)
    os.remove('./static/goods/s_' + filename)
    os.remove('./static/goods/m_' + filename)

def delete(request,uid):
    #删除会员页面
    context={}
    try:
        ob = Goods.objects.get(id=uid)
        del_oldfile(ob.picname)
        ob.delete()
        context['info']='删除成功'
    except Exception as a:
        print(a)
        context['info']='删除失败'
    finally:
        return  render(request,'myadmin/info.html',context)

def edit(request,uid):
    #加载编辑页面并判断request.method是哪一个参数
    if request.method == 'GET':
        list = Types.objects.extra(select={'_has': 'concat(path,id)'}).order_by('_has')
        for ob in list:
            ob.pname = '````' * (ob.path.count(',') - 1)
        oldfilename=Goods.objects.get(id=uid)
        context = {'goodlist': list,'goods':oldfilename}
        return render(request, 'myadmin/goods/edit.html', context)
    else:
        try:
            context={}
            b=False
            oldfilename=request.POST['oldfilename']
            if None != request.FILES.get('pic'):
                myfile=request.FILES.get('pic',None)
                if not myfile:
                    return HttpResponse('没有图片上传')
                else:
                    filename = save_img(myfile)
                    picname=filename
                    b=True
            else:
                picname=oldfilename

            ob = Goods.objects.get(id=uid)
            ob.typeid = request.POST['typeid']

            ob.goods = request.POST['goods']

            ob.company = request.POST['company']

            ob.content = request.POST['content']

            ob.price = request.POST['price']

            ob.picname = picname

            ob.store = request.POST['store']

            ob.state = 1

            ob.addtime = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            ob.save()
            if b:
                del_oldfile(myfile)
            context['info'] = '修改成功'
        except Exception as a:
            print(a)
            context['info'] = '修改失败'
        return render(request, 'myadmin/info.html', context)


def delete_d(request,uid):
    try:
        ob=Goods.objects.get(id=uid).delete()

        context = {'info': '删除成功'}

    except Exception as a:
        print(a)
        context={'info':'删除失败'}
    return render(request,'myadmin/info.html',context)