from django.shortcuts import render
from django.http import HttpResponse
from  common.models import Users,Types
import os

# Create your views here.

def index(request):
    #商品信息浏览
    list=Types.objects.extra(select={'_has':'concat(path,id)'}).order_by('_has')
    for ob in list :
        ob.pname=(ob.path.count(',')-1)*"--"
    context={'typelist':list}
    return  render(request,'myadmin/type/index.html',context)

def add(request,tid):
    #加载添加页面并判断request.method是哪一个参数
   if request.method == 'GET':
       #判断是否是一个主要分类项
       if tid == '0':
           context={'pid':tid,'path':'0,','name':'主类商品'}
       else:
           ob=Types.objects.get(id=tid)
           context = {'pid': ob.id, 'path':ob.path+str(ob.id)+",", 'name': ob.name}
       return render(request, 'myadmin/type/add.html', context)
   else:
       context={}
       try:
           ob=Types()
           ob.name=request.POST['name']
           ob.pid=request.POST['pid']
           ob.path=request.POST['path']
           ob.save()
           context['info']='添加成功'
       except Exception as a:
            print(a)
            context['info']='添加失败'
       finally:
           return render(request,'myadmin/info.html',context)
def delete(request,tid):
        try:
            context={}
            row1 = Types.objects.filter(pid=tid)
            row=row1.count()
            print(row)
            if row>0:
                context['info']='此商品下还有子类存在，请勿删除'
                return  render(request,'myadmin/info.html',context)
            ob=Types.objects.get(id=tid)
            ob.delete()
            context['info']='删除成功'
        except Exception as a:
            print(a)
            context['info']='删除失败'
        return render(request,'myadmin/info.html',context)



def edit(request,tid):
    #加载编辑页面并判断request.method是哪一个参数
    ob = Types.objects.get(id=tid)
    if request.method == 'GET':
        context={'list':ob}
        return render(request,'myadmin/type/edit.html',context)
    else:
        context={}
        try:
                ob.name = request.POST['name']
                ob.save()
                context['info'] = '修改成功'
        except Exception as a:
                print(a)
                context['info'] = '没有找到修改信息'
        finally:
                return render(request, 'myadmin/info.html', context)



