from django.shortcuts import render
from django.http import HttpResponse
from  common.models import Users
from datetime import  datetime
import  hashlib
from django.core.paginator import Paginator
from myadmin.config import Config as co
# Create your views here.

def index(request,page=1):
    #会员信息浏览
    ob=Paginator(Users.objects.all(),2)#加载分页数，分页对象
    list_s=ob.page(page)#分页对象
    page_max=ob.num_pages#分页数最大值
    page_list=ob.page_range#分页列表
    context={'page_max':page_max,'page_list':page_list,'userlist':list_s}
    return  render(request,'myadmin/users/index.html',context)

def add(request):
    #加载添加页面并判断request.method是哪一个参数
   if request.method == 'GET':
        return render(request,'myadmin/users/add.html')
   else:
       context={}
       try:
           ob=Users()
           ob.username=request.POST['username']
           m=hashlib.md5()
           m.update(bytes(request.POST['password'],encoding='utf8'))
           ob.password=m.hexdigest()
           ob.name=request.POST['name']
           ob.sex=request.POST['sex']
           ob.address=request.POST['address']
           ob.code=request.POST['code']
           ob.phone=request.POST['phone']
           ob.email=request.POST['email']
           ob.state=1
           ob.addtime=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
           ob.save()
           context['info']='添加成功'
       except Exception as a:
            print(a)
            context['info']='添加失败'
       finally:
           return render(request,'myadmin/info.html',context)
def delete(request,uid):
    #删除会员页面
    context={}
    try:
        ob=Users.objects.get(id=uid).delete()
        context['info']='删除成功'
    except:
        context['info']='删除失败'
    finally:
        return  render(request,'myadmin/info.html',context)

def edit(request,uid):
    #加载编辑页面并判断request.method是哪一个参数
    ob = Users.objects.get(id=uid)
    if request.method == 'GET':
        context={'list':ob}
        return render(request,'myadmin/users/edit.html',context)
    else:
        context={}
        try:
                # ob.username=ob.username
                ob.name = request.POST['name']
                ob.sex = request.POST['sex']
                ob.address = request.POST['address']
                ob.code = request.POST['code']
                ob.phone = request.POST['phone']
                ob.email = request.POST['email']
                ob.state = request.POST['state']
                ob.save()
                context['info'] = '修改成功'
        except Exception as a:
                print(a)
                context['info'] = '没有找到修改信息'
        finally:
                return render(request, 'myadmin/info.html', context)


def reset(request,uid):
    #重置会员密码
   ob=Users.objects.get(id=uid)
   if request.method == 'GET':
        context={'list':ob}
        return render(request,'myadmin/users/reset.html',context)
   else:
        context={}
        try:
            # ob.username=ob.username
            m = hashlib.md5()
            m.update(bytes(request.POST['repassword1'], encoding='utf8'))
            ob.password = m.hexdigest()

            ob.save()
            context['info']='修改密码成功'
        except Exception as a:
                print(a)
                context['info'] = '修改密码失败'
        finally:
                return render(request,'myadmin/info.html',context)


def select(request):
        ob=Users.objects.filter(username=request.GET['username'])
        print(ob)
        context={'userlist':ob}
        return render(request,'myadmin/users/select.html',context)

