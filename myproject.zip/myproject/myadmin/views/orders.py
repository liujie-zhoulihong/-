from django.shortcuts import render
from django.http import HttpResponse
from django.db.models import Q
from django.core.paginator import Paginator

from common.models import Goods,Users,Orders,Detail

# Create your views here.
def index(request,pIndex=1):
    '''浏览信息'''
    try:
        #获取订单信息
        mod = Orders.objects
        mywhere=[]
        # 获取、判断并封装关keyword键搜索
        kw = request.GET.get("keyword",None)
        if kw:
            # 查询收件人和地址中只要含有关键字的都可以
            list = mod.filter(Q(linkman__contains=kw) | Q(address__contains=kw))
            mywhere.append("keyword=" + kw)
        else:
            list = mod.filter()
        # 获取、判断并封装订单状态state搜索条件
        state = request.GET.get('state','')
        if state != '':
            list = list.filter(state=state)
            mywhere.append("state=" + state)

        #执行分页处理
        pIndex = int(pIndex)
        page = Paginator(list,5) #以1条每页创建分页对象
        maxpages = page.num_pages #最大页数
        #判断页数是否越界
        if pIndex > maxpages:
            pIndex = maxpages
        if pIndex < 1:
            pIndex = 1
        list2 = page.page(pIndex) #当前页数据
        plist = page.page_range   #页码数列表

        # 遍历订单信息并追加 下订单人姓名信息
        for od in list2:
            user = Users.objects.only('name').get(id=od.uid)
            od.name = user.name

        #封装信息加载模板输出
        context = {"orderslist":list2,'plist':plist,'pIndex':pIndex,'maxpages':maxpages,'mywhere':mywhere}
        return render(request,"myadmin/orders/index.html",context)
    except Exception as a:
        print(a)


def detail(request,oid):
    #后台查看商品详情的连接
    #获取用户的订单信息
    try:
        #获取订单信息
        orders = Orders.objects.get(id=oid)

        if orders != None:
            #获取用户名字
            o1 = Users.objects.only('name').get(id=orders.uid)
            orders.name=o1.name
                #获取订单详情信息
        detaile=Detail.objects.filter(orderid=oid)

        #通过遍历获取图片名字
        for o in detaile:
            o.picname = Goods.objects.only('picname').get(id=o.goodsid).picname
        #封装整理后的信息
        context={'orders':orders,'detaillist':detaile}
        return render(request,'myadmin/orders/detail.html',context)
    except:
        context={'info':'没有找到要查看的信息'}
        return render(request,'myadmin/info.html',context)


def state(request):
    global context
    try:
        #获取传递来的商品订单号
        oid = request.GET.get('oid','0')
        #获取订单信息
        list = Orders.objects.get(id=oid)
        list.state= request.GET['state']
        list.save()
        context={'info':'修改成功'}
        # return render(request,'myadmin/info.html',context)
    except Exception as a:
        print(a)
        context={'info':'修改失败'}
    finally:
        return render(request,'myadmin/info.html',context)
