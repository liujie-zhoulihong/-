"""myproject URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.urls import path,re_path
from myadmin.views import index,users,type,goods,orders



urlpatterns = [
    #后台首页
    path('',index.index,name='myadmin_index'),
    #后台登陆、退出操作
    path('login',index.login,name='myadmin_login'),
    path('login_out', index.login_out, name='myadmin_login_out'),
    path('login_verify', index.login_verify, name='myadmin_login_verify'),


    #会员信息管理首页
    re_path('users/(?P<page>[0-9]+)',users.index,name='myadmin_users_index'),
    path('users/add',users.add,name='myadmin_users_add'),
    re_path('users/del/(?P<uid>[0-9]+)',users.delete,name='myadmin_users_del'),
    re_path('users/edit/(?P<uid>[0-9]+)',users.edit,name='myadmin_users_edit'),
    re_path('users/reset/(?P<uid>[0-9]+)',users.reset,name='myadmin_users_reset'),
    re_path('users/select',users.select,name='myadmin_users_select'),



    #商品类别信息管理
    path('type',type.index,name='myadmin_type_index'),
    re_path('type/add/(?P<tid>[0-9]+)',type.add,name='myadmin_type_add'),
    re_path('type/del/(?P<tid>[0-9]+)',type.delete,name='myadmin_type_del'),
    re_path('type/edit/(?P<tid>[0-9]+)',type.edit,name='myadmin_type_edit'),


    #商品信息管理
    re_path('goods/(?P<pIndex>[0-9]+)', goods.index, name='myadmin_goods_index'),
    path('goods/add', goods.add, name='myadmin_goods_add'),
    re_path('goods/del/(?P<uid>[0-9]+)', goods.delete, name='myadmin_goods_del'),
    re_path('goods/edit/(?P<uid>[0-9]+)', goods.edit, name='myadmin_goods_edit'),
    re_path('goods/delete_d/(?P<uid>[0-9]+)', goods.delete_d, name='myadmin_goods_del_d'),


    #项目后台订单处理
    # 订单信息管理路由
    path('orders', orders.index, name="myadmin_orders_index"),#浏览订单信息
    re_path('orders/(?P<pIndex>[0-9]+)', orders.index, name="myadmin_orders_index"),#查看订单详情分页操作
    re_path('orders/detail/(?P<oid>[0-9]+)', orders.detail, name="myadmin_orders_detail"),#查看订单详情
    path('orders/state',orders.state, name="myadmin_orders_state"),#修改订单状态

]