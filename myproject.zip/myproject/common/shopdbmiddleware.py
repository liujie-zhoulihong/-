import re
from  django.shortcuts   import redirect,reverse
class ShopdbMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response
        # One-time configuration and initialization.
    def __call__(self, request):
        #定义可以不经过登录就拧访问的urls
        urllist=['/myadmin/login','/myadmin/login_out','/myadmin/login_verify']

        #获取路径
        path =request.path
        #判断路径是否是/myadmin开头并且没有在urllist列表中的，如果是跳转到登录页面
        if  re.match('/myadmin',path) and  path not in urllist:
            #判断当前用户有没有登录
            if 'adminuser' not in request.session:
            #执行跳转登录页面操作
                return redirect(reverse('myadmin_login'))
            #判断网站前台用户是否登录
        if  re.match('^/orders',path) or re.match('^/vip',path):
            #判断vipuser有没有在状态维持的会话中
            if 'vipuser' not in request.session:
                #执行跳转网站前台登录页面操作
                return redirect(reverse('web_login'))

        response = self.get_response(request)

        # Code to be executed for each request/response after
        # the view is called.
        return response

