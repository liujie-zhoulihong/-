from django.db import models
from datetime import datetime
# Create your models here.
class Users(models.Model):
    #会员信息模型
    username=models.CharField(max_length=32)#会员登录账号
    name=models.CharField(max_length=16)#会员真实姓名
    password=models.CharField(max_length=32)#登录密码
    sex=models.IntegerField(default=1)#会员性别
    address=models.CharField(max_length=255)#会员地址
    code=models.CharField(max_length=6)#邮政编号
    phone=models.CharField(max_length=16)#电话
    email=models.CharField(max_length=50)#电子邮箱
    state=models.CharField(max_length=50)#会员账户类型
    addtime=models.DateTimeField(default=datetime.now)#添加时间


    def toDict(self):
        #返回一条会员的所有信息
        return dict(
            id=self.id,
            username=self.username,
            name=self.name,
            password=self.password,
            sex=self.sex,
            address=self.address,
            code=self.code,
            phone=self.phone,
            email=self.email,
            state=self.state,
            # addtime=self.addtime

        )
    class Meta():
        #重新制定表名
        db_table = 'users'

class Types(models.Model):
    #商品信息列表
    name=models.CharField(max_length=32)
    pid=models.IntegerField(default=0)
    path=models.CharField(max_length=255)
    class Meta():
       #重新指定商品类别表名
        db_table='type'
#商品信息模型
class Goods(models.Model):
    typeid = models.IntegerField() #商品类别id
    goods = models.CharField(max_length=32)#商品名
    company = models.CharField(max_length=50)#生产厂家
    content = models.TextField()#详情描述
    price = models.FloatField()#商品价格
    picname = models.CharField(max_length=255)#图片名字
    store = models.IntegerField(default=0)#库存量
    num = models.IntegerField(default=0)#被购买数量
    clicknum = models.IntegerField(default=0)#点击次数
    state = models.IntegerField(default=1)#状态
    addtime = models.DateTimeField(default=datetime.now)#添加时间

    def toDict(self):
        #返回商品的一条信息
        return {'id':self.id,'typeid':self.typeid,'goods':self.goods,'company':self.company,'price':self.price,'picname':self.picname,'store':self.store,'num':self.num,'clicknum':self.clicknum,'state':self.state}

    class Meta:
                db_table = "goods"  # 更改表名

# 订单模型
class Orders(models.Model):
    uid = models.IntegerField()#当前登录用户的名字
    linkman = models.CharField(max_length=32)#联系人
    address = models.CharField(max_length=255)#地址
    code = models.CharField(max_length=6)#邮编
    phone = models.CharField(max_length=16)#电话
    addtime = models.DateTimeField(default=datetime.now)#购买时间
    total = models.FloatField()#总金额
    state = models.IntegerField()#状态 0、新订单 1、已发货 2、已收货 3、无效订单

    class Meta:
        db_table = "orders"  # 更改表名

#订单详情模型
class Detail(models.Model):
    orderid = models.IntegerField()#订单id号
    goodsid = models.IntegerField()#商品id号
    name = models.CharField(max_length=32)#商品名称
    price = models.FloatField()#商品价格
    num = models.IntegerField()#商品数量

    class Meta:
        db_table = "detail"  # 更改表名