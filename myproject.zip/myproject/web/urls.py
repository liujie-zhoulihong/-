"""myproject URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.urls import path,re_path
from web.views import index,cart,orders,vip





urlpatterns = [
    #前台首页
    path('',index.index,name='index'), #首页
    path('list', index.lists, name='list'), #列表
    re_path('list/(?P<pIndex>[0-9]+)', index.lists, name='list'), #分页列表
    re_path('detail/(?P<pid>[0-9]+)', index.detail, name='detail'), #详情


    #前台会员注册，登录，退出
    path('login', index.login, name='web_login'),#登录
    path('login_out', index.login_out, name='web_login_out'),#退出
    path('login_register', index.register, name='web_reginster'),#注册账号
    path('login_register_add', index.register_add, name='web_reginster_add'),#检查账号

    #购物车信息
    path('cart',cart.index, name='cart_index'),#购物车首页
    re_path('cart/add/(?P<gid>[0-9]+)',cart.add, name='cart_add'),#商品信息添加
    path('cart/clear',cart.clear, name='cart_clear'),#商品信息清空
    path('cart/change', cart.change, name='cart_change'),#商品信息修改
    re_path('cart/del/(?P<gid>[0-9]+)',cart.delete, name='cart_del'),#商品删除

    #订单出路
    path('orders/add',orders.add,name='orders_add'),#添加详情
    path('orders/confirm',orders.confirm,name='orders_confirm'),#商品信息确认
    path('orders/insert',orders.insert,name='orders_insert'),#执行商品信息添加

    # 会员中心
    path('vip/orders', vip.viporders, name='vip_orders'),  # 会员中心我的订单
    path('vip/odstate', vip.odstate, name='vip_odstate'),  # 修改订单状态（确认收货）
    path('vip/info', vip.info,name='vip_info'), #会员中心的个人信息
    path('vip/update', vip.update,name='vip_update'), #执行修改会员信息
    path('vip/reset', vip.reset,name='vip_reset'), #重置密码表单




]
