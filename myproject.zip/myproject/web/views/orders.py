from django.shortcuts import render
from common.models import Types,Orders,Detail
from datetime import datetime
# Create your views here.

#公共信息加载
def index_list(request):
    list= Types.objects.filter(pid=0)
    context={'typelist':list}
    return context


def add(request):
    #订单表单
    context=index_list(request)
    #获取下单的id号
    ids=request.GET.get('ids','')
    #判断是否选择商品
    if len(ids) == 0:
        context['info']='请选择需要结算的商品'
        #返回信息到商品信息提示页面
        return render(request,'web/ordersinfo.html',context)
    #gidlist传递过来的结算商品的id
    gidlist = ids.split(',')
    #从购物车获取结算的商品信息id，并放入到数据库订单信息表中
    shoplist=request.session['shoplist']
    orderslist={}
    total=0.0
    #遍历商品结算商品的id列表，从session中获取结算商品的信息并添加到订单表中，商品金额只能从session中获得
    for gid in gidlist:
        orderslist[gid] = shoplist[gid]
        total += shoplist[gid]['price'] * shoplist[gid]['m']
    #把订单信息和订单总金额放入到订单表中，
    request.session['orderslist']=orderslist
    request.session['total']=total
    return render(request,'web/ordersadd.html',context)

def confirm(request):
    #商品信息确认
    context = index_list(request)
    return render(request,'web/ordersconfirm.html',context)


def insert(request):
    #执行商品信息添加
    context = index_list(request)
    try:
        #执行添加商品订单操作
        ob=Orders()
        ob.uid=request.session['vipuser']['id']#获取下单人的账号
        ob.linkman=request.POST.get('linkman') #获取收货人信息
        ob.address=request.POST.get('address') #获取收货人地址
        ob.phone = request.POST.get('phone')  #获取收货人电话
        ob.addtime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")#下单时间，格式化时间
        ob.total = request.session['total']  #订单总金额，只能从session中获取
        ob.state = 0  #0新订单
        ob.save()
        #执行订单详情操作
        orderslist=request.session['orderslist']#获取订单操作中的商品信息
        shoplist = request.session['shoplist']#获取购物车信息
        for shop in orderslist.values(): #遍历订单操作的值
            del shoplist[str(shop['id'])] #删除购物车中已经结算的商品
            ov=Detail() #添加订单详情
            ov.orderid=ob.id #订单号
            ov.goodsid=shop['id'] #商品id
            ov.name = shop['goods'] #商品名字
            ov.price = shop['price'] #商品价格
            ov.num = shop['m'] #购买商品数量
            ov.save()
        del request.session['orderslist'] #从session中删除结算的商品信息
        del request.session['total'] #删除商品金额
        request.session['shoplist'] = shoplist #重新添加修改后的购物车
        context['info']='订单添加成功，订单号：'+str(ob.id)
        return render(request,'web/ordersinfo.html',context)
    except Exception as a:
        print(a)
        context['info']='系统繁忙，请稍后操作'
        return render(request,'web/ordersinfo.html',context)