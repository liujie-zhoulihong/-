from django.shortcuts import render
from common.models import Types,Orders,Detail,Goods,Users

import  hashlib
from django.shortcuts import reverse,redirect,HttpResponse
# Create your views here.

#公共信息加载
def index_list(request):
    list= Types.objects.filter(pid=0)
    context={'typelist':list}
    return context


def viporders(request):
    #当前用户订单
    context = index_list(request)

    #获取用户的所有订单信息
    oblist=Orders.objects.filter(uid = request.session['vipuser']['id'])
    #遍历当前用户的所有订单信息，为他添加订单详情
    for ob in oblist:
        #订单详情的orderid等于订单信息的id
        delist = Detail.objects.filter(orderid = ob.id)
        #遍历订单详情获取商品图片
        for od in delist:
            #获取所有的商品图片.获得id=订单详情的商品id.获得图片
            od.picname = Goods.objects.only('picname').get(id = od.goodsid).picname
        ob.detaillist=delist
    context['orderslist']=oblist
    return render(request,'web/viporders.html',context)

def odstate(request):
    #修改订单状态
    try:
        oid=request.GET.get('oid','0')
        ob=Orders.objects.get(id=oid)
        ob.state=request.GET['state']
        ob.save()
        return  redirect(reverse('vip_orders'))
    except Exception as a:
        print(a)
        return HttpResponse('订单处理失败')


def info(request):
    context = index_list(request)
    #获取用户的登录信息
    ob = request.session['vipuser']
    context={'userlist':ob}
    return render(request,'web/infomation.html',context)


def update(request):
    oblist = request.session['vipuser']
    if request.method == 'GET':
        context={'list':oblist}
        return render(request,'web/vip_update.html',context)
    else:
        try:
            #获取session中的会员信息的id，并从Usser表中获取此id的一条完整数据
            ob = Users.objects.get(id = oblist['id'])
            ob.name = request.POST['name']
            ob.sex = request.POST['sex']
            ob.address = request.POST['address']
            ob.code = request.POST['code']
            ob.phone = request.POST['phone']
            ob.email = request.POST['email']
            ob.state = request.POST['state']
            ob.save()
            request.session['vipuser']=ob.toDict()
            context={'info':"修改个人信息成功"}
            return  render(request,'web/info.html',context)
        except Exception as a:
            print(a)
            context={'info':'修改个人信息失败'}
            return render(request,'web/info.html',context)


def reset(request):
    #判断请求方式：
    ob = request.session['vipuser']
    if request.method == 'GET':
        context = {'userlist':ob}
        return render(request,'web/reset.html',context)
    else:
        context = {}
        try:
            oa = Users.objects.get(id=ob['id'])
            m = hashlib.md5()
            m.update(bytes(request.POST['repassword1'], encoding='utf8'))
            oa.password = m.hexdigest()
            oa.save()
            request.session['vipuser']=oa.toDict()
            context['info'] = '修改密码成功'
        except Exception as a:
            print(a)
            context['info'] = '修改密码失败'
        finally:
            return render(request, 'web/info.html', context)