from django.shortcuts import render,HttpResponse



from django.shortcuts import reverse,redirect

from common.models import Types,Goods
# Create your views here.

#公共信息加载
def index_list(request):
    list= Types.objects.filter(pid=0)
    context={'typelist':list}
    return context

def index(request):
   context=index_list(request)
   if 'shoplist' not in request.session:
       request.session['shoplist'] = {}
   return render(request,'web/cart.html',context)


def add(request,gid):
    #商品信息添加进购物车，获取一条商品信息
    ob=Goods.objects.get(id=gid)
    #获取商品的所有信息
    shop=ob.toDict()
    #添加一个购买量属性
    shop['m']=int(request.POST.get('m',1))
    shoplist=request.session.get('shoplist',{})
    print(shoplist)
    #判断商品是否在购物车中
    if gid in shoplist:
        shoplist[gid]['m'] += shop['m']
    else:
        shoplist[gid] = shop
    #把购物车信息放回到session
    request.session['shoplist']=shoplist

    return redirect(reverse('cart_index'))

def clear(request):
    #强行给session附一个空值
    request.session['shoplist']={}
    return redirect(reverse('cart_index'))


def change(request):
    #获取session中的商品信息
    shoplist=request.session['shoplist']
    #获取onlick传递过来的id和num值
    shopid=request.GET.get('gid',0)
    num = int(request.GET.get('num',1))
    #判断使商品数量不小于1
    if num < 1:
        num = 1
    #给session中的m值重新赋值
    shoplist[shopid]['m']= num
    #保存商品信息到session中
    request.session['shoplist']=shoplist
    return redirect(reverse('cart_index'))


def delete(request,gid):
    #获取session中的数据
   shoplist=request.session['shoplist']
    #删除传递过来的gid对应的商品信息
   del shoplist[gid]
    #重新保存商品信息
   request.session['shoplist']=shoplist
    #重定向到购物车中
   return redirect(reverse('cart_index'))