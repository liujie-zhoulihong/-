from django.shortcuts import render
from django.http import HttpResponse
from myadmin.views.index import login_verify
import hashlib
from django.shortcuts import reverse,redirect
from django.core.paginator import Paginator
from common.models import Users,Types,Goods
# Create your views here.

#公共信息加载
def index_list(request):
    list= Types.objects.filter(pid=0)
    context={'typelist':list}
    return context
#商城首页
def index(request):
    context=index_list(request)
    return render(request,'web/index.html',context)

#商品信息列表
def lists(request,pIndex=1):
    context = index_list(request)
    #查询商品信息
    mod = Goods.objects
    mywhere=[]
    tid = int(request.GET.get('tid',0))
    if tid>0:
        list = mod.filter(typeid__in=Types.objects.only('id').filter(pid=tid))
        mywhere.append('tid='+str(tid))
    else:
        list = mod.filter()

    #执行分页操作
    pIndex=int(pIndex)
    page=Paginator(list,2)#添加分页数据，以每页5条数据展示
    maxpages=page.num_pages#数据的总数
    if pIndex > maxpages:
        pIndex=maxpages
    if pIndex<1:
        pIndex=1
    list2=page.page(pIndex)#获取当前页面的数据
    plist=page.page_range#页码数列表
    #封装各种信息
    context['goodlist'] = list2
    context['plist']=plist
    context['pIndex']=pIndex
    context['maxpages']=maxpages
    context['mywhere']=mywhere
    return render(request,'web/list.html',context)

#商品详情
def detail(request,pid):
    context={}
    context = index_list(request)
    ob= Goods.objects.get(id = pid)
    ob.clicknum +=1
    ob.save()
    context={'goods':ob}
    return render(request,'web/detail.html',context)




def login(request):
    # 判断method是提交还是请求
    if request.method == 'GET':
        # 是请求，跳转到登录页面
        return render(request, 'web/login.html')
    else:
        context = {}
        # 判断验证码
        f1 = request.session['verify']
        f2 = request.POST['code']
        if f1.lower() != f2.lower():
            context['info'] = '验证码错误'
            return render(request, 'web/login.html', context)
        try:
            # 定义一个user接受username这一行数据
            user = Users.objects.get(username=request.POST['username'])
            # 判断状态，是否是会员
            if user.state == 1 or user.state == 0:
                # 如果是，提取输入密码的md5值并且与数据库中的md5值进行判断，密码是否一致
                m = hashlib.md5()
                m.update(bytes(request.POST['password'], encoding='utf8'))
                if user.password == m.hexdigest():
                    # 添加会员到状态维持的列表中
                    request.session['vipuser'] = user.toDict()
                    return redirect(reverse('index'))
                else:
                    context['info'] = '账号或者密码输入错误'
                    return render(request, 'web/login.html', context)
            else:
                context['info'] = '账号或者密码输入错误'
                return render(request, 'web/login.html', context)
        except Exception as aa:
            print(aa)
            context['info'] = '账号或者密码输入错误'
        return redirect(reverse('web_login'))
def login_out(request):
    # 删除sesstion会话中存储的信息
    del request.session['vipuser']
    return redirect(reverse('web_login'))

def register(request):
    #注册
    if request.method == 'GET':
        return render(request, "web/register.html")
    else:
        try:
            ob = Users()
            ob.username = request.POST.get('username')
            m = hashlib.md5()
            m.update(bytes(request.POST.get('password'), encoding='utf8'))
            ob.password = m.hexdigest()
            ob.state=1
            ob.save()
            context={'info':'注册成功'}
            return render(request, 'web/info.html', context)
        except Exception as aa:
            print(aa)
            context = {'info': '注册失败'}
            return render(request,'web/register.html',context)
def register_add(request):
    if request.method == 'POST':
        username = request.POST.get('username')  # 获取提交的账号
    # 判断用户账号是否存在
        if Users.objects.filter(username=username).exists():
            return HttpResponse('0')
        else:
            return HttpResponse('1')
    else:
        return HttpResponse(status=403)