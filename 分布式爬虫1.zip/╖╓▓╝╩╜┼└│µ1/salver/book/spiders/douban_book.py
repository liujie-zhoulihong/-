# -*- coding: utf-8 -*-
import scrapy,re
from ..items import BookItem
from scrapy_redis.spiders import RedisSpider
class DoubanBookSpider(RedisSpider):
    name = 'douban_book'
    # allowed_domains = ['book.douban.com']
    # start_urls = ['https://book.douban.com/tag/']
    redis_key = "douban:start_urls"
    #实例化操作
    def __init__(self, *args, **kwargs):
        # Dynamically define the allowed domains list.
        domain = kwargs.pop('domain', '')
        self.allowed_domains = filter(None, domain.split(','))
        super(DoubanBookSpider, self).__init__(*args, **kwargs)

    def parse(self, response):
        # 找出所有的书籍链接
        tag_urls = response.xpath("//div[@class='article']//table[@class='tagCol']//a/@href").getall()
        # 遍历循环获得完整的分类url
        for tag_url in tag_urls:
            book_url = response.urljoin(tag_url)
            # 发送请求并用回调函数继续下一步操作
            yield scrapy.Request(url=book_url, callback=self.parse_tag_url)

    def parse_tag_url(self, response):
        # 获取每一个分类下的书籍的url
        book_urls = response.xpath("//ul[@class='subject-list']/li/div/a/@href").getall()
        for book_url in book_urls:
            url = book_url
            yield scrapy.Request(url, callback=self.parse_book)
        # 判断是否有下一页
        next_url = response.xpath("//span[@class='next']/a/@href").get()
        if next_url:
            next_url = response.urljoin(next_url)
            yield scrapy.Request(url=next_url, callback=self.parse_tag_url)

    def parse_book(self, response):

        '''最终获取每一本书的所需内容'''
        infos = response.xpath("//div[@id='info']//text()").getall()
        info = list(map(lambda x: x.replace(':', ''), infos))
        text = list(filter(lambda x: re.search(r'\S', x), info))
        name = author = press = orig = translator = imp_d = number_of_pages = pricing = binding_and_layout = series = isbn = grade = observer = ""
        name = response.xpath("//div[@id='mainpic']/a/@title").get()
        for index, x in enumerate(text):
            x = x.strip()
            if x == '作者':
                author = text[index + 1]
                author = re.sub(r'\s', '', author)
            elif x == '出版社':
                press = text[index + 1].strip()
            elif x == '原作名':
                orig = text[index + 1].strip()
            elif x == '译者':
                translator = text[index + 1].strip()
            elif x == '出版年':
                imp_d = text[index + 1].strip()
            elif x == '页数':
                number_of_pages = text[index + 1].strip()
            elif x == '定价':
                pricing = text[index + 1].strip()
            elif x == '装帧':
                binding_and_layout = text[index + 1].strip()
            elif x == '丛书':
                series = text[index + 1].strip()
            elif x == 'ISBN':
                isbn = text[index + 1].strip()
        grade = response.xpath("//strong[@class='ll rating_num ']/text()").get()
        observer = response.xpath("//a[@class='rating_people']/span/text()").get()
        yield BookItem(name=name, author=author, press=press, orig=orig, translator=translator, imp_d=imp_d,number_of_pages=number_of_pages, pricing=pricing, binding_and_layout=binding_and_layout,series=series, isbn=isbn, grade=grade, observer=observer)


