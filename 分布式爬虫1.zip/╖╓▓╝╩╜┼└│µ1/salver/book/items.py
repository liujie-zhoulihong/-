# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class BookItem(scrapy.Item):
    name = scrapy.Field()#书名
    author = scrapy.Field()#作者
    press = scrapy.Field()#出版社
    orig = scrapy.Field()#原作名
    translator = scrapy.Field()#译者
    imp_d = scrapy.Field()#出版年
    number_of_pages = scrapy.Field()#页数
    pricing = scrapy.Field()#定价
    binding_and_layout = scrapy.Field()#装帧
    series = scrapy.Field()#丛书
    isbn = scrapy.Field()#ISBN
    grade = scrapy.Field()#评分
    observer = scrapy.Field()#评论人数
