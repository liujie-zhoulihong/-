import redis,pymongo,json

def main():
    r=redis.Redis(host='localhost',port=6379,decode_responses=True)
    m=pymongo.MongoClient(host='localhost',port=27017)
    #创建数据库名
    db=m['dbdouban']
    #创建空间
    sheet = db['book']
    while True:
        source,data = r.blpop(['douban_book:items'])
        item = json.loads(data)
        sheet.insert(item)

        try:
            print (u"Processing: %(name)s <%(link)s>"%item)
        except KeyError:
            print (u"Error procesing: %r"%item)
if __name__ == '__main__':
    main()