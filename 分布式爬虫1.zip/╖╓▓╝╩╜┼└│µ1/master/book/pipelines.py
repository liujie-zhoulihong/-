# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html
import redis,re
class BookPipeline(object):
    def __init__(self):
        self.r=redis.Redis(host='localhost',port=6379,decode_responses=True)
    def process_item(self, item, spider):
        if re.search('book.douban.com',item['url']):
            self.r.lpush('douban:start_urls',item['url'])
        else:
            self.r.lpush('douban:start_urls',item['url'])
        return item

   
