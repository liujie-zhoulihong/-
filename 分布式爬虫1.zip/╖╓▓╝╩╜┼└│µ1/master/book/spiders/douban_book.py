# -*- coding: utf-8 -*-
import scrapy,re
from 分布式爬虫1.master.book.items import BookItem

class DoubanBookSpider(scrapy.Spider):
    name = 'douban_book'
    allowed_domains = ['book.douban.com']
    start_urls = ['https://book.douban.com/tag/']
    item = BookItem()
    def parse(self, response):
        #找出所有的书籍链接
        tag_urls = response.xpath("//div[@class='article']//table[@class='tagCol']//a/@href").getall()
        #遍历循环获得完整的分类url
        for tag_url in tag_urls:
            book_url = response.urljoin(tag_url)
            #发送请求并用回调函数继续下一步操作
            yield scrapy.Request(url=book_url,callback=self.parse_tag_url)

    def parse_tag_url(self,response):
        #获取每一个分类下的书籍的url
        book_urls =  response.xpath("//ul[@class='subject-list']/li/div/a/@href").getall()
        for book_url in book_urls:
            url = book_url
            yield scrapy.Request(url,callback=self.parse_book)
        #判断是否有下一页
        next_url = response.xpath("//span[@class='next']/a/@href").get()
        if next_url:
            next_url = response.urljoin(next_url)
            yield scrapy.Request(url=next_url,callback=self.parse_tag_url)

    def parse_book(self,response):
        item = self.item
        item['url']=response.url
        return item



