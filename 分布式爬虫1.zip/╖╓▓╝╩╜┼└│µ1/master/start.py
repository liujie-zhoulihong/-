from scrapy import cmdline

cmdline.execute("scrapy crawl douban_book".split(" "))